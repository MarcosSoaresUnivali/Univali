# UNIVALI
UNIVALI developments by Marcos Paulo Soares [Eng. de Computação - 2023/2]

<img src="21814_PDS/screenshot.jpeg" width="800"/>